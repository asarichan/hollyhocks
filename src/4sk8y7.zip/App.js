import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <div class="gorira">
        <h2>本当に出品しますか？</h2>
        <button class="example">はい</button>
        <button class="example1">いいえ</button>
      </div>
    </div>
  );
}
